---
name: "dc-pptx"
description: "Build DataCense-branded PowerPoint decks in the approved DC Template v3 design (near-black ground, warm gold highlight words, rounded dark cards, glow backgrounds). Use for any presentation, webinar, workshop, training or pitch deck or .pptx in a DataCense context, or when the user says 'our deck template', 'DC template', 'brand deck'. Not for Word or PDF."
---

# DataCense presentation template — v3 (default design)

The approved design is **DC Template v3**. Reference file: `DC Template v3 - Sample.pptx` in the user's OneDrive folder `24 AI Workshop/04 L1 Planning/Worshop Slide/03 Plan Version 03`. It replaces the older design in `scripts/dc_pptx.js` (white logo plate + gold header rule + gold-ruled footer, 10 × 5.625 canvas). Use the old library's layouts only if the user explicitly asks for the old style; its Lucide icon renderer and bundled Poppins fonts are still useful.

## Start from the v3 builder

A working v3 builder is saved in the DC Growth Plan project as `claude/dc-template-v3-builder.js` (read it with the Projects tool). It uses pptxgenjs, react-icons/lu and sharp from `/opt/npm-tools/node_modules/`. Copy it, keep its helpers (`slide`, `title`, `eyebrow`, `card`, `disc`, `pill`, `T`, icon renderer) and replace the slide content.

Setup:
1. Stage `DC Template v3 - Sample.pptx` and copy from `ppt/media/` into `assets/`: `Slide-1-image-1.png` → glow_title.png, `Slide-5-image-1.png` → glow_divider.png, `Slide-16-image-1.png` → glow_center.png, `Slide-18-image-1.png` → glow_close.png, `image-1-2.png` → logo.png.
2. Copy `<skill-dir>/assets/fonts/*.ttf` to `~/.fonts` and run `fc-cache -f` before rendering.

Everything stays native PowerPoint (text boxes, shapes, tables, charts). Icons are small PNGs. Never rasterise a whole slide, table or chart.

## Design tokens (measured from the v3 file)

- Canvas 13.333 × 7.5 in. Side margin 0.89 in. Slide title at y ≈ 0.72.
- Background `0B0B0E` solid on content slides; glow images on title, section-break and closing slides.
- Card `15151B`, border `2A2A34` 0.5 pt, rounded corners (radius ≈ 0.1 in).
- Icon disc `2A2213`, border `3A3220`, gold line icon at 50% of disc size.
- Gold `F2B33D` (highlight words, icons, eyebrows, numerals, pills). Title text `F5F2EA`. Body `B8B5AE`. Muted `9C9AA6`.
- Font Poppins. Slide titles 34–36 pt bold with ONE key word or phrase in gold ("Today's **roadmap**"). Title-slide headline 52 pt. Eyebrows 11 pt bold, gold, letter-spacing 3, uppercase. Card headings 15–21 pt bold; body 12–15 pt.
- Logo only on the title slide, on a white rounded plate (x 0.89, y 0.62, 2.3 × 0.56 in; logo 1.98 × 0.435). Never recolour or stretch it.
- No header rule, no footer, no page numbers.
- Emphasis: a gold 1 pt border, or a gold-filled card with dark `0B0B0E` text and icons, for the single most important item on a slide.

## Layout patterns in v3

| Content | Pattern |
|---|---|
| Opening | Logo plate, eyebrow, 52 pt headline, 4 stat cards, one bottom strip with check icon |
| Session plan | Roadmap rows: gold left bar, PART pill, icon, gold label, white description |
| Chapter break | Glow background, eyebrow, icon disc, title, large faint numeral on the right |
| 3 ideas | Numbered columns 01/02/03 with gold top tick and icon disc |
| Progression / maturity | Ascending level cards, last one gold-filled |
| 4–8 items | Icon-card grid |
| Method | Step cards with chevrons |
| Numbers | Stat cards (big value + small label) |
| Comparison matrix | Shape-built table with check boxes, gold-bordered summary row |
| Nuance | Icon-disc bullets + gold-bordered callout card |
| Data | Native chart + key-takeaways card |

## Visual-first rules

- Every content slide carries icons, a diagram, a chart or an image. Every bullet gets an icon disc.
- Headings ≤ 6 words; card bodies ≤ 16 words; max 4 bullets. Cut text before shrinking type.
- Icons are gold Lucide line icons only, one per idea, never repeated on a slide; no emoji or clip-art.
- Do not reproduce third-party brand logos; use neutral icons and tell the user they can paste official logos onto the icon discs.
- Use the user's real screenshots when supplied. Never invent a screenshot of a real product or stock photos of people.
- Stay inside the user's agenda and content; rephrase for clarity, add only what makes it simpler.

## Content discipline

Never invent a client name, date, statistic or testimonial. Verify fast-changing facts (model names, context windows, prices) with web search and date them on the slide ("checked <month year>"). Sample strings in the v3 reference file are illustrative only.

## Fonts

Poppins is not installed by default on Windows or macOS. When delivering, tell the user to install the bundled Poppins fonts, or offer a rebuild with Calibri. Do not silently pick one.

## Quality check — required before delivering

```bash
python /mnt/skills/public/pptx/scripts/office/validate.py <deck>.pptx
markitdown <deck>.pptx | grep -iE "lorem|ipsum|TODO|\[insert|sample"
python /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf <deck>.pptx
rm -f slide-*.jpg && pdftoppm -jpeg -r 100 <deck>.pdf slide
```

Look at every rendered slide for: text clipped or wrapping mid-word, overlaps, eyebrows on two lines, large empty areas, low-contrast text, a slide with no visual, repeated icons, page numbers. Fix in the build script and re-render. Never hand-edit the XML.